Unzip any zip files if needed. StrikeFont definition files must go on a folder named 'AdditionalFontData' inside the folder containing the Cuis image. Import fonts like this:

"To install large fonts, suitable for QHD and Retina displays"
StrikeFont install: 'DejaVu'.

"To install monospaced fonts"
StrikeFont install: 'DejaVu Sans Mono'.
Preferences setDefaultFontFamilyTo: 'DejaVu Sans Mono'.
Preferences defaultFont17.