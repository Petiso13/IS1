#!/bin/bash
vm/squeak CuisUniversity-3805.image